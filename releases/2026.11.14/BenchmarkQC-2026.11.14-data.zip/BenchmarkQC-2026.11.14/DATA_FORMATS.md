# Data formats

All paths in `catalog.json` and metadata records are relative to the archive
root. Energies are in hartree, coordinates and bond lengths in angstrom, and
angles in degrees unless explicitly labelled otherwise. Orbital and qubit
indices are zero-based. NPZ files contain named NumPy arrays; JSON and CSV
files contain definitions and reference values.

## Model and point indices

`references/model_index.csv` has one row per model representation. `si_table_case` identifies its case in SI Table I; a blank entry denotes the additional C2 natural-orbital representation. `point_count` is the number of indexed geometries or integral frames. `model_metadata` gives the path to the model definition.

`catalog.json` contains a `points` array. Each point is identified by `<molecule>/<model>/<point>`. The `r` prefix denotes a bond length in angstrom, with `p` as the decimal separator; for example, `r2p0000` denotes 2.0000 angstrom. Angle, torsion and parent-frame identifiers are defined explicitly in the corresponding `geometry.json`.

## Common files at each point

| File | Contents |
| --- | --- |
| `geometry.json` | Coordinates and geometric parameters, or an integral-frame identifier for a parent-Hamiltonian model |
| `hamiltonian.npz` | Numeric Pauli representation of the qubit Hamiltonian |
| `integrals.npz` | Spatial one-electron integrals, two-electron integrals and scalar constant |
| `reference_results.json` | CASCI, CISD and CCSD reference energies and available state/correlation diagnostics |
| `metadata.json` | Model, state, active-space dimensions, file paths and data availability |
| `array_inventory.json` | Names, dimensions and data types of arrays in the point’s numerical archives |
| `orbitals.npz` | Available orbital coefficients, rotations, occupations, indices and overlap arrays |
| `records/` | Additional integral, orbital, wavefunction, density-matrix, SCF, correlation or algorithm-trajectory records |

The first six files are supplied for every point. The optional orbital file
and additional records are identified by `metadata.json`. Array names, shapes
and types are listed in each point's `array_inventory.json`.

## Geometry and electronic state

`geometry.json` uses `coordinates` with shape (number of atoms, 3) and
`coordinate_unit: "angstrom"`. A model defined directly by a parent integral
Hamiltonian has `coordinates: null` and `definition_type: "parent integral frame"`.

`target_spin_2S` denotes twice the target total spin S.
`spin_projection_2Ms` denotes twice its spin projection M_S.
These quantities are distinct. With N active electrons,
N_alpha=(N+2M_S)/2 and N_beta=(N-2M_S)/2 define the fixed-number sector.
The model description specifies the reference and target states.

## Qubit Hamiltonian

Every `hamiltonian.npz` has the same three fields and is readable with
`numpy.load(path, allow_pickle=False)`:

| Array | Meaning |
| --- | --- |
| `pauli_words` | One string of I, X, Y and Z characters per term; string length equals the number of qubits |
| `pauli_coefficients` | Complex coefficient array in the same order as `pauli_words` |
| `n_qubits` | Scalar number of qubits |

The Hamiltonian is H=sum_j c_j P_j. Character q of a Pauli string acts on
qubit q. In determinant integers, qubit q corresponds to bit q, so qubit 0
is the least significant bit. Spin orbitals are interleaved:
alpha(p)=2p and beta(p)=2p+1. The qubit mapping is Jordan-Wigner.
The identity-term coefficient is part of the operator and must be retained.

## Spatial integrals

Every `integrals.npz` is readable with `allow_pickle=False` and contains:

| Array | Shape | Meaning |
| --- | --- | --- |
| `one_body_integrals` | (n,n) | Spatial one-electron matrix h[p,q] |
| `two_body_integrals` | (n,n,n,n) | Two-electron integrals (pq\|rs) in PySCF chemist ordering |
| `core_constant` | scalar | Additive energy constant Ecore |

Here n is the number of active spatial orbitals. The second-quantized operator is

```text
H = Ecore + sum(pq,sigma) h[p,q] a†[p,sigma] a[q,sigma]
    + 1/2 sum(pqrs,sigma,tau) (pq|rs)
          a†[p,sigma] a†[r,tau] a[s,tau] a[q,sigma].
```

`model.json` specifies the energy convention. The total molecular convention
includes nuclear repulsion and frozen-orbital contributions. A parent-integral
model instead uses its stated parent scalar constant and frozen-orbital
contributions. `metadata.json` identifies the spatial-integral representation
and the availability of orbital coefficients.

## Reference values and orbital arrays

CASCI is the exact diagonalization reference within the stated active space
and target symmetry sector. CISD and CCSD values refer to the stated orbital
and reference-determinant definitions. Status fields accompany values whose
interpretation depends on convergence or root selection. An unassigned energy
is JSON `null` and a blank CSV cell.

The SI table uses `CASCI_hartree`, `CISD_hartree` and `CCSD_hartree`. The corresponding fields in each point’s `reference_results.json` are `casci_energy_hartree`, `cisd_energy_hartree` and `ccsd_energy_hartree`.

`H025_nats` (`renyi_0p25_nats` in point records) is the Rényi entropy of order 0.25 evaluated from normalized determinant probabilities using natural logarithms and a probability cutoff of 1e-15. `C2` (`cumulant_C2` in point records) is one quarter of the squared Frobenius norm of the two-body cumulant over active spin orbitals. `N92` is
the smallest number of descending determinant weights summing to at least 0.92.
The tabulated classification is a reduced-active-space, orbital-frame-dependent
proxy. Its definitions are given in `references/classification.json`.

Orbital coefficient matrices use basis functions or parent orbitals as rows
and molecular orbitals as columns. The applicable basis and frame are identified
in model metadata and numerical records. Natural occupations and orbital
rotations retain their recorded ordering. Additional CI vectors, reduced
density matrices and trajectory arrays are described by their field names and
the accompanying array inventory.


`model_basis_identity` denotes an identity transformation within a model
orbital basis. `formal_closed_shell_occupations` denotes a formal closed-shell
occupation pattern. These arrays do not specify molecular AO-to-MO coefficients
or natural occupations. The availability of molecular coefficients is identified
by point metadata.

Where supplied, `records/construction.json` defines the basis, SCF initialization,
orbital selection, inactive space and molecular orbital arrays.
`records/regenerated_integrals.npz` contains independently calculated spatial
integrals in the aligned deposited orbital basis, with the same array names
and chemist convention as `integrals.npz`.
`records/hamiltonian_validation.json` gives Pauli-coefficient, matrix, spectrum
and spin checks. The orthogonal alignment does not adjust the scalar constant.

Molecular construction records contain AO-to-MO coefficients together with the
integrals calculated from those coefficients. `coefficient_integral_pairing`
identifies the matching arrays. Shared `construction_scan.npz` records use the
bond-length axis specified by `distance_angstrom`; point metadata identify the
corresponding zero-based index. The CI vectors and active density matrices use
the final canonical active-orbital basis. Validation records document orbital
orthonormality, convergence and the target spin state.

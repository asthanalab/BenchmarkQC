# BenchmarkQC: strongly correlated chemical test systems for quantum algorithms

Version 2026.11.14

Dataset DOI: https://doi.org/10.5281/zenodo.24237572

Supporting dataset for *Strongly correlated chemical test systems for quantum
algorithms*, by Srivathsan Poyyapakkam Sundar, Vibin Abraham, Bo Peng and
Ayush Asthana.

BenchmarkQC contains molecular active-space Hamiltonians, one- and two-electron
integrals, orbital information and electronic-structure reference results for
quantum-algorithm benchmarks. The collection covers the 18 models in Supporting
Information (SI) Table I and an additional C2 CASCI natural-orbital representation.
Its 19 model directories contain 68 geometry or integral-frame records across
nine molecular families. Records with different orbital representations of the
same geometry are indexed separately.

## Dataset contents

CAS(ne,no) denotes ne active electrons in no spatial orbitals.

| Molecular system | Active spaces (ne,no) | SI Table I cases |
| --- | --- | --- |
| N2 | (4,4), (6,6), (10,8) | 1–3, 18 |
| FeS | (6,6), (14,10) | 4, 10 |
| [Fe2S2(SCH3)4]2− | (4,4), (6,6), (8,6), (8,8), (10,10) | 5–8, 11 |
| U2 | (6,6), (6,10) | 9, 12 |
| C2H4 | (2,2) | 13 |
| CH2 | (6,6) | 14 |
| C2 | (8,8) | 15 |
| O2 | (12,8) | 16 |
| FeH | (9,10) | 17 |

N2 CAS(10e,8o) is supplied in canonical RHF and CASCI natural-orbital
representations. C2 CAS(8e,8o) includes active-HF and CASCI natural-orbital
representations. The basis, orbital definition, electronic state, relativistic
treatment and energy convention are specified for each model and point.

## File organization

Every model uses the following hierarchy. Paths in the catalog and metadata
are relative to the archive root.

```text
BenchmarkQC-2026.11.14/
├── README.md
├── DATA_FORMATS.md
├── CITATION.cff
├── LICENSE
├── catalog.json
├── MANIFEST.json
├── SHA256SUMS
├── references/
│   ├── model_index.csv
│   ├── si_table_I.csv
│   ├── si_table_I.json
│   ├── classification.json
│   ├── coverage.json
│   └── parent_hamiltonians/
└── systems/<molecule>/<model>/
    ├── model.json
    ├── shared/                     # Model-wide records, where supplied
    └── points/<geometry_or_frame>/
        ├── geometry.json
        ├── hamiltonian.npz
        ├── integrals.npz
        ├── reference_results.json
        ├── metadata.json
        ├── array_inventory.json
        ├── orbitals.npz            # Orbital arrays, where supplied
        └── records/                # Additional numerical calculation records
```

`references/model_index.csv` maps SI case numbers to model directories, active
spaces, basis sets and record counts. `catalog.json` indexes all 68 points and
links their data files. Each `model.json` defines the chemical model; each
point's `metadata.json` specifies the target state, spin projection, data paths
and orbital-coefficient availability. `array_inventory.json` lists array names,
shapes and types.

`references/si_table_I.csv` and `references/si_table_I.json` give full-precision
values for the 32 geometry or integral-frame rows of SI Table I.
`references/classification.json` defines the determinant-based classification.
The parent FCIDUMP is in `references/parent_hamiltonians/`.

## Reading the data

Start with `references/model_index.csv` to select a model and `catalog.json`
to locate its points. The numerical archives contain named NumPy arrays.
The following example reads the first indexed Hamiltonian using Python and
NumPy; all NPZ files can be opened with `allow_pickle=False`.

```python
from pathlib import Path
import json
import numpy as np

root = Path("BenchmarkQC-2026.11.14")
catalog = json.loads((root / "catalog.json").read_text())
point = catalog["points"][0]
with np.load(root / point["hamiltonian"], allow_pickle=False) as data:
    pauli_words = data["pauli_words"]
    coefficients = data["pauli_coefficients"]
    n_qubits = int(data["n_qubits"])
```

`DATA_FORMATS.md` specifies energy and coordinate units, tensor ordering,
qubit conventions and the definitions of reference quantities. `MANIFEST.json`
and `SHA256SUMS` provide file sizes and integrity hashes.

## Citation and contact

Citation metadata are provided in `CITATION.cff`. Cite the dataset and the
associated article when using these data. The license is provided in `LICENSE`.

Correspondence: Ayush Asthana (ayush.asthana@und.edu) and Bo Peng
(peng398@pnnl.gov).

Related software:

- BenchmarkQC: https://github.com/asthanalab/BenchmarkQC
- QCANT: https://github.com/asthanalab/QCANT
